<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Feedback Form</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background: linear-gradient(135deg, #4f46e5, #6d28d9);
        }
        .glass {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center">

<div class="w-full max-w-2xl glass p-6">
    <div class="text-center mb-6">
        <img src="{{ asset('Redback Studios.png') }}" alt="Logo" class="h-16 mx-auto mb-4">
        <h2 class="text-2xl font-bold text-white">Student Feedback Form</h2>
    </div>
    @if(session('success'))
    <div class="bg-green-100 text-green-800 p-3 mb-4 rounded-lg">
        {{ session('success') }}
    </div>
    @endif
    <form action="{{ route('feedback.store') }}" method="POST">
        @csrf

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" name="name" placeholder="Name" class="p-3 rounded-lg border border-gray-300">
            <input type="email" name="email" placeholder="Email" class="p-3 rounded-lg border border-gray-300">
            <input type="text" name="mobile" placeholder="Mobile No" class="p-3 rounded-lg border border-gray-300">
            <input type="text" name="college_name" placeholder="College Name" class="p-3 rounded-lg border border-gray-300">
            <input type="text" name="university_name" placeholder="University Name" class="p-3 rounded-lg border border-gray-300">
            <input type="date" name="date" class="p-3 rounded-lg border border-gray-300">
        </div>

        <textarea name="feedback" placeholder="Your Feedback" rows="4" class="w-full p-3 mt-4 rounded-lg border border-gray-300"></textarea>

        <button type="submit" class="w-full mt-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-2 rounded-lg hover:scale-105 transition transform">
            Submit Feedback
        </button>
    </form>
</div>

</body>
</html>
