<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Feedback;

class FeedbackController extends Controller
{
   

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'mobile' => 'required',
            'college_name' => 'required|string|max:255',
            'university_name' => 'required|string|max:255',
            'feedback' => 'required|string',
            'date' => 'required|date',
        ]);

        Feedback::create($request->all());

        return back()->with('success', 'Thank you for your feedback!');
    }
}
