<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Feedback;

class AdminController extends Controller
{
    public function index()
    {
        $feedbacks = Feedback::all();
        return view('dashboard', compact('feedbacks'));
    }
}
