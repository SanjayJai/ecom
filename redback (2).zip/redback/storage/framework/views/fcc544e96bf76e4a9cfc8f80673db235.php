<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Student Feedback</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="container mx-auto py-12">
    <h2 class="text-3xl font-bold text-center mb-6">Admin Dashboard - Student Feedback</h2>

    <div class="flex justify-between mb-4">
        <a href="" class="bg-green-500 text-white px-4 py-2 rounded-lg">
            Download All as Excel
        </a>
        <a href="" class="bg-red-500 text-white px-4 py-2 rounded-lg">
            Logout
        </a>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border rounded-lg">
            <thead>
                <tr class="bg-gray-200 text-gray-600">
                    <th class="py-2 px-4">Name</th>
                    <th class="py-2 px-4">Email</th>
                    <th class="py-2 px-4">Mobile</th>
                    <th class="py-2 px-4">Date</th>
                    <th class="py-2 px-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-gray-700">
                    <td class="py-2 px-4"><?php echo e($feedback->name); ?></td>
                    <td class="py-2 px-4"><?php echo e($feedback->email); ?></td>
                    <td class="py-2 px-4"><?php echo e($feedback->mobile); ?></td>
                    <td class="py-2 px-4"><?php echo e($feedback->date); ?></td>
                    <td class="py-2 px-4">
                        <a href="<?php echo e(route('feedback.pdf', $feedback->id)); ?>" class="bg-blue-500 text-white px-3 py-1 rounded-lg">
                            Download PDF
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html><?php /**PATH D:\Laravel\redback\resources\views/dashboard.blade.php ENDPATH**/ ?>